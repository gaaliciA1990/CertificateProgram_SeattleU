package queryrunner;

public class ConstVariables {
    final static String HOST = "projectdbs.cn3usp1d3gjf.us-east-1.rds.amazonaws" +
            ".com";
    final static String USER = "admin";
    final static String PASS = "lKMNGgnpCzu4Wj7e0lPq";
    final static String DB = "ProjectGroup5";
}
