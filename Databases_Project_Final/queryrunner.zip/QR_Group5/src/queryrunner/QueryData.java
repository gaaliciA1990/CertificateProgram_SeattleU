/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package queryrunner;

import java.util.ArrayList;
import java.util.List;

/**
 * @author mckeem
 */
public class QueryData {
    QueryData() {
    }

    /**
     * This builds an object containing the inputs required to run a query
     * It applies to the console and the GUI versions
     * @param query
     * @param parms - changed to a list instead of an array because it's easier to add items
     * @param likeparms - changed to a list instead of an array because it's easier to add items
     * @param isAction - this determines how the query is executed
     * @param isParm - determines if the program needs to display textboxes and how to build the sql string
     */
    QueryData(String query, List<String> parms, List<Boolean> likeparms,
              boolean isAction, boolean isParm) {
        m_queryString = query;
        m_arrayParms = parms;
        m_arrayLikeParms = likeparms;
        m_isAction = isAction;
        m_isParms = isParm;
    }
    
/*    void Set(String query, ArrayList<String>parms, boolean isAction,
boolean isParm) {
        m_queryString = query;
        m_arrayParms = parms;
        m_isAction = isAction;
        m_isParms = isParm;
    }
*/

    String GetQueryString() {
        return m_queryString;
    }

    int GetParmAmount() {
        if (m_arrayParms == null)
            return 0;
        else
            return m_arrayParms.size();
    }


    String GetParamText(int index) {
        return m_arrayParms.get(index);
    }

    boolean GetLikeParam(int index) {
        return m_arrayLikeParms.get(index);
    }

    List<Boolean> GetAllLikeParams() {
        return m_arrayLikeParms;
    }

    boolean IsQueryAction() {
        return m_isAction;
    }

    boolean IsQueryParm() {
        return m_isParms;
    }

    private String m_queryString;
    private List<String> m_arrayParms;
    private boolean m_isAction;
    private boolean m_isParms;
    private List<Boolean> m_arrayLikeParms;
}
