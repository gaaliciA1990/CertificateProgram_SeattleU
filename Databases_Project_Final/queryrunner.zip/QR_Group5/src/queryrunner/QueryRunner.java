/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package queryrunner;

import java.util.ArrayList;
import java.util.HashMap;
import java.sql.*;
import java.util.Scanner;

/**
 * QueryRunner takes a list of Queries that are initialized in it's constructor
 * and provides functions that will call the various functions in the QueryJDBC class
 * which will enable MYSQL queries to be executed. It also has functions to provide the
 * returned data from the Queries. Currently the eventHandlers in QueryFrame call these
 * functions in order to run the Queries.
 */
public class QueryRunner {


    public QueryRunner() {
        this.m_jdbcData = new QueryJDBC();
        m_updateAmount = 0;
        m_queryArray = new ArrayList<>();
        m_error = "";

        this.m_projectTeamApplication = "ProjectGroup5";    // THIS NEEDS TO CHANGE FOR YOUR APPLICATION

        //    QueryText is a String that represents your query. It can be anything but Stored Procedure
        //    Parameter Label Array  (e.g. Put in null if there is no Parameters in your query, otherwise put in the Parameter Names)
        //    LikeParameter Array  is an array I regret having to add, but it is necessary to tell QueryRunner which parameter has a LIKE Clause. If you have no parameters, put in null. Otherwise put in false for parameters that don't use 'like' and true for ones that do.
        //    IsItActionQuery (e.g. Mark it true if it is, otherwise false)
        //    IsItParameterQuery (e.g.Mark it true if it is, otherwise false)
        String sql1 = "";

        // We dynamically add our queries so the existing code is no longer needed
    }

    @SuppressWarnings("finally")
    public HashMap<String, QueryData> getQueries() throws java.sql.SQLException {
        HashMap<String, QueryData> queries = new HashMap<String, QueryData>();
        boolean isAction = false;

        //String query, String[] parms, boolean [] likeparms, boolean isAction, boolean isParm
        try {
            String sql = "SELECT * FROM reports ORDER BY report_name;";
            queries = m_jdbcData.ExecuteReportsQuery(sql);
            for (String key : queries.keySet()) {
                this.m_queryArray.add(queries.get(key));
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            return queries;
        }

    }


    public int GetTotalQueries() {
        int i = 0;
        return m_queryArray.size();
    }

    public int GetParameterAmtForQuery(int queryChoice) {
        QueryData e = m_queryArray.get(queryChoice);
        return e.GetParmAmount();
    }

    public String GetParamText(int queryChoice, int parmnum) {
        QueryData e = m_queryArray.get(queryChoice);
        return e.GetParamText(parmnum);
    }

    public String GetQueryText(int queryChoice) {
        QueryData e = m_queryArray.get(queryChoice);
        return e.GetQueryString();
    }

    /**
     * Function will return how many rows were updated as a result
     * of the update query
     *
     * @return Returns how many rows were updated
     */

    public int GetUpdateAmount() {
        return m_updateAmount;
    }

    /**
     * Function will return ALL of the Column Headers from the query
     *
     * @return Returns array of column headers
     */
    public String[] GetQueryHeaders() {
        return m_jdbcData.GetHeaders();
    }

    /**
     * After the query has been run, all of the data has been captured into
     * a multi-dimensional string array which contains all the row's. For each
     * row it also has all the column data. It is in string format
     *
     * @return multi-dimensional array of String data based on the resultset
     * from the query
     */
    public String[][] GetQueryData() {
        return m_jdbcData.GetData();
    }

    public String GetProjectTeamApplication() {
        return m_projectTeamApplication;
    }

    public boolean isActionQuery(int queryChoice) {
        QueryData e = m_queryArray.get(queryChoice);
        return e.IsQueryAction();
    }

    public boolean isParameterQuery(int index) {
        QueryData e = m_queryArray.get(index);
        return e.IsQueryParm();
    }


    public boolean ExecuteQuery(int queryChoice, String[] parms) {
        boolean bOK = true;
        QueryData e = m_queryArray.get(queryChoice);
        bOK = m_jdbcData.ExecuteQuery(e.GetQueryString(), parms, e.GetAllLikeParams());
        return bOK;
    }


    public boolean ExecuteUpdate(int queryChoice, String[] parms) {
        boolean bOK = true;
        QueryData e = m_queryArray.get(queryChoice);
        bOK = m_jdbcData.ExecuteUpdate(e.GetQueryString(), parms);
        m_updateAmount = m_jdbcData.GetUpdateCount();
        return bOK;
    }


    public boolean Connect(String szHost, String szUser, String szPass, String szDatabase) {

        boolean bConnect = m_jdbcData.ConnectToDatabase(szHost, szUser, szPass, szDatabase);
        if (bConnect == false)
            m_error = m_jdbcData.GetError();
        return bConnect;
    }

    public boolean Disconnect() {
        // Disconnect the JDBCData Object
        boolean bConnect = m_jdbcData.CloseDatabase();
        if (bConnect == false)
            m_error = m_jdbcData.GetError();
        return true;
    }

    public String GetError() {
        return m_error;
    }

    public String consoleGetHost(Scanner scan) {
        String host;

        System.out.print("Enter hostname [leave blank for default]: ");
        host = scan.nextLine();
        if (host.isEmpty()) {
            host = ConstVariables.HOST;
        }
        return host;
    }

    public String consoleGetUser(Scanner scan) {
        String user;
        System.out.print("Enter User [default = admin]: ");
        user = scan.nextLine();
        if (user.isEmpty()) {
            user = ConstVariables.USER;
        }
        return user;
    }

    public String consoleGetPass(Scanner scan) {
        String password = "";
        while (password.isEmpty()) {
            System.out.print("Enter password: ");
            password = scan.nextLine();
            if (password.isEmpty()) {
                System.out.println("Password is required!");
            }
        }
        return password;
    }

    public String consoleGetDB(Scanner scan) {
        String database;
        System.out.print("Enter database [default = ProjectGroup5]: ");
        database = scan.nextLine();
        if (database.isEmpty()) {
            database = ConstVariables.DB;
        }
        System.out.println(); //Add new line for spacing
        return database;
    }

    void printQueryResults(String[][] results) {
        int columnCount = 0;

        for (int row = 0; row < results.length; row++) {
            System.out.print(results[row][0]);
            for (int col = 1; col < results[row].length; col++) {
                System.out.print(", " + results[row][col]);
            }
            System.out.println(); // print a new line to start the next row
        }
        System.out.println(); //formatting line
    }

    private QueryJDBC m_jdbcData;
    private String m_error;
    private String m_projectTeamApplication;
    private ArrayList<QueryData> m_queryArray;
    private int m_updateAmount;

    /**
     * @param args the command line arguments - input argument set in the project configuration
     */
    public static void main(String[] args) throws SQLException {

        Scanner scan = new Scanner(System.in);
        String host, user, pass, db;
        int querySelect;
        final QueryRunner queryrunner = new QueryRunner();

        if (args.length == 0) {
            java.awt.EventQueue.invokeLater(new Runnable() {
                public void run() {

                    try {
                        new QueryFrame(queryrunner).setVisible(true);
                    } catch (SQLException throwables) {
                        throwables.printStackTrace();
                    }
                }
            });
        }
        else {
            //this is controlled in the IntelliJ config
            if (args[0].equals("-console")) {
                host = queryrunner.consoleGetHost(scan);
                user = queryrunner.consoleGetUser(scan);
                pass = queryrunner.consoleGetPass(scan);
                db = queryrunner.consoleGetDB(scan);
                queryrunner.Connect(host, user, pass, db);
                queryrunner.getQueries();
                // pull the queries from our table
                int n = queryrunner.GetTotalQueries();

                if (n == 0) {
                    System.out.println("Connection failed! Ending program.");
                }
                else {
                    System.out.println("There are " + n + " queries to run. Please select which query to run: ");

                    // Converts the keys to a string in an Array so we can print
                    // the title of the queries
                    HashMap<String, QueryData> queries = queryrunner.getQueries();
                    String[] keys = queries.keySet().toArray(new String[queries.size()]);

                    // Ask the user to select a query. If invalid option, repeat ask
                    while (true) {
                        do {
                            // print the query options
                            for (int i = 1; i <= n; i++) {
                                System.out.println((i) + ". " + keys[i - 1]);
                            }
                            System.out.println("0 [Exit]");
                            System.out.print("Enter option to run or 0 to quit: ");
                            querySelect = scan.nextInt();
                            if (querySelect > n || querySelect < 0) {
                                System.out.println("Invalid entry! Try again.");
                            }
                            scan.nextLine(); //clear line
                            System.out.println(); //formatting line
                        } while (querySelect > n || querySelect < 0);

                        // redefine query select to pull the true selection
                        querySelect = querySelect - 1;

                        //check if user wants to quit the program and disconnect them from the server and end the program
                        if (querySelect == -1) {
                            System.out.println("Thank you for using the query program. You're now being disconnected.");
                            System.out.println("...");
                            queryrunner.Disconnect();
                            System.out.println("Goodbye!");
                            break;
                        }

                        String[] params = new String[0]; //initialize param array to be an empty array

                        System.out.println("This is your chosen query: ");
                        String sql_str = queryrunner.GetQueryText(querySelect);
                        sql_str.replace("FROM", "\nFROM");
                        System.out.println(sql_str);
                        System.out.println(); // formatting line

                        // check if the query has a parameter and requests the user to enter their parameters
                        if (queryrunner.isParameterQuery(querySelect)) {
                            System.out.println("This query has parameters to fill in!");
                            int amt = queryrunner.GetParameterAmtForQuery(querySelect);
                            params = new String[amt];
                            for (int j = 0; j < amt; j++) {
                                System.out.print("Enter " + queryrunner.GetParamText(querySelect, j) +
                                        ": ");
                                params[j] = scan.nextLine();
                            }
                        }
                        // check if the query is an Action query and execute
                        if (queryrunner.isActionQuery(querySelect)) {
                            queryrunner.ExecuteUpdate(querySelect, params);
                            System.out.println("Number of rows updated: " + queryrunner.GetUpdateAmount());
                            System.out.println();
                        } else {
                            //Execute the query
                            queryrunner.ExecuteQuery(querySelect, params);
                            String[] header = queryrunner.GetQueryHeaders();
                            System.out.println(); //formatting line
                            // print the header columns
                            for (int i = 0; i < header.length; i++) {
                                System.out.print(header[i] + ", ");
                            }
                            System.out.println(); //formatting line

                            System.out.println("Results from query " + (querySelect+1) + ":");
                            String[][] results = queryrunner.GetQueryData(); //store the results in an array of strings

                            // print the results in a table format
                            queryrunner.printQueryResults(results);
                        }
                    }
                }
            }
        }
    }
}

