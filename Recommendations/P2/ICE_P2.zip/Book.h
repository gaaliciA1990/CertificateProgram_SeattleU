//
// Created by garci on 9/17/2020.
//

#ifndef P2_BOOK_H
#define P2_BOOK_H

#include <iostream>
#include <wsman.h>
#include "Rating.h"
#include "Member.h"


class Book {
public:
    /**
     * Constructor for the book object that is set to XX.
     * @param title The books' title
     * @param author The books' author
     * @param isbn The books unique identifier
     * @param year  The year the book was published
     */
    Book(std::string title, std::string author, std::string isbn, int year);

    /**
     * Copy constructor for the book object that passed through a Member
     * object.
     * @param copy The member object to copy
     */
    Book(const Book *copy);

    /**
     * Assignment operator overload to set the equal sign to copy values to
     * a new address
     * @param rhs   The object on the right hand side (rhs)
     * @return a book object
     */
    Book &operator=(const Book &rhs);

    /**
     * Destructor for the book object
     */
    ~Book();

    /**
    * This method will ask the use for the file name to download data from
    * @param fileName  The file to pull data from
    */
    void getFile(std::string fileName);
    // This ^ should be in the main

    /**
     * This will add a book to the file
     */
    void addBook(std::string userISBN);

    /**
     * Returns recommendations for the logged in user based on similar titles
     * with similar ratings
     * @param account
     */
    void getRecommendations(Member account);


private:
    std::string isbn;   // book identified
    std::string author; // author of the book, first and last name
    std::string title;  // string holding the title
    int year;   // year the book was published
    int index;  // track the books per member


};

#endif //P2_BOOK_H