//
// Created by garci on 9/17/2020.
//

#ifndef P2_MEMBER_H
#define P2_MEMBER_H

#include <iostream>
#include <wsman.h>
#include "Rating.h"
#include "Book.h"

class Member {
public:
    /**
     * Constructor for the member object that is set to XX.
     * @param XX argument passed through, not sure what it would be yet
     */
    Member(const int XX);

    /**
     * Copy constructor for the member object that passed through a Member
     * object.
     * @param copy The member object to copy
     */
    Member(const Rating *copy);

    /**
     * Assignment operator overload to set the equal sign to copy values to
     * a new address
     * @param rhs   The object on the right hand side (rhs)
     * @return a member object
     */
    Member &operator=(const Rating &rhs);

    /**
     * Destructor for the member object
     */
    ~Member();

    /**
     * (this should probably be in main). This will ask the user to enter
     * their member id to login and view their data
     * @param memID The users accountID
     */
    void login(int memID);

    /**
     * Adds a new member to the member file and generates an new accountID id
     * for them
     * @param name
     */
    void addMember(std::string name);

    /**
     * Tracks who is logged into the program at a time
     * @param memID The users accountID
     * @return returns true if member is logged in, else false
     */
    bool getLoginStatus(int memID);

    /**
     * (this should probably be in main). This will end the session for the
     * the user when they ask to log out
     */
    void logout();

private:
    std::string memberName;
    int accountID;  // variable for the randomly generated account number
    bool status; // shows if the member is logged in (true) or not (false)
};

#endif //P2_MEMBER_H