//
// Created by garci on 9/17/2020.
//

#ifndef P2_RATING_H
#define P2_RATING_H

#include <iostream>
#include <wsman.h>
#include "Book.h"
#include "Member.h"

class Rating {
public:
    /**
     * Constructor for the rating object that is set to initial rating.
     * @param newRating The initial rating for a book, set to default 0
     *        indicating the using hasn't rated the book
     */
    Rating(const int newRating);

    /**
     * Copy constructor for the rating object that passed through a Member
     * object.
     * @param copy The rating object to copy
     */
    Rating(const Rating *copy);

    /**
     * Assignment operator overload to set the equal sign to copy values to
     * a new address
     * @param rhs   The object on the right hand side (rhs)
     * @return a rating object
     */
    Rating &operator=(const Rating &rhs);

    /**
     * Destructor for the rating object
     */
    ~Rating();


    /**
     * This method will ask the use for the file name to download data from
     * @param fileName  The file to pull data from
     */
    void getFile(std::string fileName);
    // This should be in the main header and class

    /**
     * This method will show all ratings for a member
     * @param member  The member to search the ratings for
     */
    void viewRatings(Book member);

    /**
     * This method will set the rating for a given book and store it in the file
     * @param isbn  The book to assign the rating to, which will map to the
     * book list
     */
    void rateBook(Book isbn);


private:
    int rating;
    Book title;
    Book isbn
    Book author;
    Member account;

};

#endif //P2_RATING_H